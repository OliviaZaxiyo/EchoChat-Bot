from flask import Flask, request, jsonify, render_template
import json
import os
import base64
import uuid
from datetime import datetime
import re

# Create app with explicit template folder path
template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
app = Flask(__name__, template_folder=template_dir)

# Load intents from JSON file
try:
    with open('intents.json', 'r') as f:
        intents_data = json.load(f)
except FileNotFoundError:
    print("ERROR: intents.json file not found. Make sure it exists in the same directory as app.py")
    intents_data = {"intents": []}

# Directory for uploaded images
UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Print current directory and template directory for debugging
print(f"Current working directory: {os.getcwd()}")
print(f"Template directory: {template_dir}")
print(f"Templates exist: {os.path.exists(template_dir)}")
if os.path.exists(template_dir):
    print(f"Files in templates directory: {os.listdir(template_dir)}")

# User session storage
user_sessions = {}

def get_response(user_message, user_id, user_role=None):
    """Get a response from the chatbot based on user message."""
    # Lowercase the message for easier matching
    user_message = user_message.lower()
    
    # Check if we have the user's role, if not assume waste seller as default
    if user_id not in user_sessions:
        user_sessions[user_id] = {"role": "waste_seller", "context": {}}
    
    if user_role and user_role != user_sessions[user_id]["role"]:
        user_sessions[user_id]["role"] = user_role
        return f"I'll now assist you as a {user_role.replace('_', ' ').title()}. How can I help you today?"
    
    # Get the user's current role
    current_role = user_sessions[user_id]["role"]
    
    # Check for role-specific intents first
    for intent in intents_data["intents"]:
        if "roles" in intent and current_role in intent["roles"]:
            for pattern in intent["patterns"]:
                if re.search(pattern.lower(), user_message):
                    return intent["responses"][0]
    
    # Check for universal intents
    for intent in intents_data["intents"]:
        if "roles" not in intent or "all" in intent["roles"]:
            for pattern in intent["patterns"]:
                if re.search(pattern.lower(), user_message):
                    return intent["responses"][0]
    
    # Handle specific waste identification requests
    waste_types = {
        "plastic": "Plastic is recyclable! Please clean and sort it by type (PET, HDPE, etc). You can post it under the 'plastic' category.",
        "paper": "Paper is recyclable! Keep it dry and bundle it together. You can post it under the 'paper' category.",
        "glass": "Glass is recyclable! Please wash and pack safely to avoid breakage. You can post it under the 'glass' category.",
        "metal": "Metal is valuable recyclable material! Clean it and sort by type if possible. You can post it under the 'metal' category.",
        "e-waste": "E-waste needs special handling! It contains valuable metals and hazardous materials. Please post it under the 'e-waste' category."
    }
    
    for waste_type, response in waste_types.items():
        if waste_type in user_message:
            return response
    
    # Default response if no match found
    default_responses = {
        "waste_seller": "I'm here to help you identify waste types and find the best disposal methods. Could you tell me more about what you're trying to dispose of?",
        "waste_buyer": "As a waste buyer, I can help you find quality materials and estimate their value. What materials are you looking for?",
        "product_seller": "I can help you with upcycling ideas and guidance on creating sustainable products. What materials are you working with?",
        "product_buyer": "I'm here to help you find sustainable products made from recycled materials. What kind of product are you looking for?",
        "delivery_volunteer": "I can help with pickup coordination and route optimization. What delivery-related question do you have?"
    }
    
    return default_responses.get(current_role, "I'm not sure how to help with that. Could you rephrase your question?")

def process_image(image_data, user_id):
    """Process uploaded image and return a response."""
    image_type = "unknown"
    
    # This is a simplified mock image recognition
    # In a real implementation, this would use computer vision/ML to identify waste types
    
    # For demo purposes, let's randomly classify the image
    import random
    waste_types = ["plastic", "paper", "glass", "metal", "e-waste", "organic"]
    image_type = random.choice(waste_types)
    
    # Store the image type in user context
    if user_id not in user_sessions:
        user_sessions[user_id] = {"role": "waste_seller", "context": {}}
    user_sessions[user_id]["context"]["last_image_type"] = image_type
    
    responses = {
        "plastic": "This looks like plastic waste! It's recyclable. Clean and sort by type. Estimated value: ₹8-15/kg depending on quality.",
        "paper": "I see paper waste! Keep it dry and bundle it together. Estimated value: ₹5-10/kg.",
        "glass": "This appears to be glass waste. Handle with care to avoid breakage. Estimated value: ₹3-7/kg.",
        "metal": "I identify this as metal waste. Very valuable! Estimated value: ₹20-150/kg depending on the type.",
        "e-waste": "This looks like electronic waste. It requires special handling but contains valuable materials. Estimated value varies widely.",
        "organic": "This appears to be organic waste. Great for composting! You can create your own compost or connect with urban farmers."
    }
    
    return responses.get(image_type, "I can't clearly identify the waste type from this image. Could you provide more details?")

@app.route('/')
def index():
    try:
        return render_template('index.html')
    except Exception as e:
        return f"Error rendering template: {str(e)}", 500

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get('message', '')
    user_id = data.get('userId', str(uuid.uuid4()))
    user_role = data.get('role', None)
    
    response = get_response(user_message, user_id, user_role)
    
    return jsonify({
        'response': response,
        'userId': user_id
    })

@app.route('/api/upload-image', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    file = request.files['image']
    user_id = request.form.get('userId', str(uuid.uuid4()))
    
    if file.filename == '':
        return jsonify({'error': 'No image selected'}), 400
    
    if file:
        # Save the image
        filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex}.jpg"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        
        # Process the image and get a response
        response = process_image(filepath, user_id)
        
        return jsonify({
            'response': response,
            'userId': user_id,
            'imageUrl': f"/static/uploads/{filename}"
        })

if __name__ == '__main__':
    app.run(debug=True)